# mypackage
My own Python Package
# building this package locally
'python setup.py sdist'<br>
# installing this package from GitHub
'pip install git+https://github.com/mlungiseleli-notshokovu/mypackage.git'<br>
# updating this package from GitHub
'pip install --upgrade git+https://github.com/mlungiseleli-notshokovu/mypackage.git'<br>
